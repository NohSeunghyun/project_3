package vo.login;

import java.sql.Date;

public class CompanyGroupMemberBean {
	private String comgrp_member_id;
	private String comgrp_member_pw;
	private String comgrp_member_category;
	private String comgrp_member_name;
	private String comgrp_manager_name;
	private String comgrp_member_companyno;
	private String comgrp_manager_phone;
	private String comgrp_member_email;
	private Date comgrp_member_date;
	private String comgrp_member_grade;
	
	public String getComgrp_member_id() {
		return comgrp_member_id;
	}
	public void setComgrp_member_id(String comgrp_member_id) {
		this.comgrp_member_id = comgrp_member_id;
	}
	public String getComgrp_member_pw() {
		return comgrp_member_pw;
	}
	public void setComgrp_member_pw(String comgrp_member_pw) {
		this.comgrp_member_pw = comgrp_member_pw;
	}
	public String getComgrp_member_category() {
		return comgrp_member_category;
	}
	public void setComgrp_member_category(String comgrp_member_category) {
		this.comgrp_member_category = comgrp_member_category;
	}
	public String getComgrp_member_name() {
		return comgrp_member_name;
	}
	public void setComgrp_member_name(String comgrp_member_name) {
		this.comgrp_member_name = comgrp_member_name;
	}
	public String getComgrp_manager_name() {
		return comgrp_manager_name;
	}
	public void setComgrp_manager_name(String comgrp_manager_name) {
		this.comgrp_manager_name = comgrp_manager_name;
	}
	public String getComgrp_member_companyno() {
		return comgrp_member_companyno;
	}
	public void setComgrp_member_companyno(String comgrp_member_companyno) {
		this.comgrp_member_companyno = comgrp_member_companyno;
	}
	public String getComgrp_manager_phone() {
		return comgrp_manager_phone;
	}
	public void setComgrp_manager_phone(String comgrp_manager_phone) {
		this.comgrp_manager_phone = comgrp_manager_phone;
	}
	public String getComgrp_member_email() {
		return comgrp_member_email;
	}
	public void setComgrp_member_email(String comgrp_member_email) {
		this.comgrp_member_email = comgrp_member_email;
	}
	public Date getComgrp_member_date() {
		return comgrp_member_date;
	}
	public void setComgrp_member_date(Date comgrp_member_date) {
		this.comgrp_member_date = comgrp_member_date;
	}
	public String getComgrp_member_grade() {
		return comgrp_member_grade;
	}
	public void setComgrp_member_grade(String comgrp_member_grade) {
		this.comgrp_member_grade = comgrp_member_grade;
	}
	
}
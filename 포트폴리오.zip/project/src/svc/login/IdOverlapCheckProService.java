package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class IdOverlapCheckProService {

		public boolean isIdOverlapChk(String id) {//아이디 중복체크
			boolean isIdOverlapChk = false;
			Connection con = null;
			try {
				con = getConnection();
				LoginDAO loginDAO = LoginDAO.getInstance();
				loginDAO.setConnection(con);
				
				isIdOverlapChk = loginDAO.isIdOverlapChk(id);
			} catch (Exception e) {
				System.out.println("isIdOverlapChkService에러" + e);
			} finally {
				close(con);
			}
			return isIdOverlapChk;
		}
}

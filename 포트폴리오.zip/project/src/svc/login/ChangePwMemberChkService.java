package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class ChangePwMemberChkService {

	public String isChangePwMemberCategory(String id, String originPw) {
		String isMemberCategory = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
		
			isMemberCategory = loginDAO.isChangePwMemberCategory(id, originPw);
		} catch (Exception e) {
			System.out.println("isMemberCategoryService에러" + e);
		} finally {
			close(con);
		}
		return isMemberCategory;
	}

}

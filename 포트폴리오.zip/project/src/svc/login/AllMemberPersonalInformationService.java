package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;
import java.util.ArrayList;

import dao.LoginDAO;
import vo.login.AdminMemberBean;
import vo.login.CompanyGroupMemberBean;
import vo.login.NormalMemberBean;

public class AllMemberPersonalInformationService {

	//모든 회원정보 조회 전 비밀번호, 핸드폰번호 일치를 통한 본인확인
	public String chkPwPhone(String id, String pw, String phone) {
		String successPwPhone = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
			
			successPwPhone = loginDAO.chkPwPhone(id, pw, phone);
		} catch (Exception e) {
			System.out.println("allMemberInfoChkPwPhoneService에러" + e);
		} finally {
			close(con);
		}
		return successPwPhone;
	}

	//모든 일반회원 정보조회
	public ArrayList<NormalMemberBean> getNormalMemberList() {
		ArrayList<NormalMemberBean> normalMemberList = null;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
			
			normalMemberList = loginDAO.getNormalMemberList();
		} catch (Exception e) {
			System.out.println("getNormalMemberListService에러" + e);
		} finally {
			close(con);
		}
		return normalMemberList;
	}

	//모든 기업/단체회원 정보조회
	public ArrayList<CompanyGroupMemberBean> getComgrpMemberList() {
		ArrayList<CompanyGroupMemberBean> comgrpMemberList = null;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
			
			comgrpMemberList = loginDAO.getComgrpMemberList();
		} catch (Exception e) {
			System.out.println("getComgrpMemberListService에러" + e);
		} finally {
			close(con);
		}
		return comgrpMemberList;
	}

	//모든 관리자 정보조회
	public ArrayList<AdminMemberBean> getAdminMemberList() {
		ArrayList<AdminMemberBean> adminMemberList = null;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
			
			adminMemberList = loginDAO.getAdminMemberList();
		} catch (Exception e) {
			System.out.println("getAdminMemberListService에러" + e);
		} finally {
			close(con);
		}
		return adminMemberList;
	}

}

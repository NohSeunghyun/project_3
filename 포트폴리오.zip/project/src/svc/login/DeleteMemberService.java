package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class DeleteMemberService {

	//일반회원 회원탈퇴 Service
	public boolean isNormalMemberDelete(String id) {
		boolean isNormalMemberDeleteSuccess = false;
		int deleteCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
		
			deleteCount = loginDAO.isNormalMemberDelete(id);
			
			if (deleteCount > 0) {
				commit(con);
				isNormalMemberDeleteSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("isNormalMemberDeleteService에러" + e);
		} finally {
			close(con);
		}
		return isNormalMemberDeleteSuccess;
	}

	//기업/단체회원 회원탈퇴 Service
	public boolean isComgrpMemberDelete(String id) {
		boolean isComgrpMemberDeleteSuccess = false;
		int deleteCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
		
			deleteCount = loginDAO.isComgrpMemberDelete(id);
			
			if (deleteCount > 0) {
				commit(con);
				isComgrpMemberDeleteSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("isComgrpMemberDeleteService에러" + e);
		} finally {
			close(con);
		}
		return isComgrpMemberDeleteSuccess;
	}

}

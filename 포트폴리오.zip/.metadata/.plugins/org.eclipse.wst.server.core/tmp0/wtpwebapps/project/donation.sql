drop table campaign_history_tbl;
drop table campaign_list_tbl;
drop table campaign_tbl;
drop table donation_tbl;
drop table admin_tbl;
drop table comgrp_member_tbl;
drop table normal_member_tbl;
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
create table normal_member_tbl(
normal_member_id varchar(30) not null primary key,
normal_member_pw varchar(30) not null,
normal_member_name varchar(30) not null,
normal_member_birth varchar(10) not null,
normal_member_phone varchar(15) not null,
normal_member_gender varchar(1) not null,
normal_member_email varchar(50),
normal_member_date date not null,
normal_member_grade varchar(3) not null default 'C'
);

insert into normal_member_tbl values('nsh11111', 'nsh11111', '노', '1993-09-27', '010-0000-0000', 'M', 'tatsos93@Nate.com', now(), default);
insert into normal_member_tbl values('jjh11111', 'jjh11111', '주', '1991-05-01', '010-0000-0001', 'M', 'abc@Naver.com', now(), default);
insert into normal_member_tbl values('kmj11111', 'kmj11111', '김', '1990-11-15', '010-0000-0002', 'M', 'def@Nate.com', now(), default);

select * from normal_member_tbl;

create table comgrp_member_tbl(
comgrp_member_id varchar(30) not null primary key,
comgrp_member_pw varchar(30) not null,
comgrp_member_category varchar(1) not null,
comgrp_member_name varchar(30) not null,
comgrp_manager_name varchar(30) not null,
comgrp_member_companyno varchar(12) not null,
comgrp_manager_phone varchar(15) not null,
comgrp_member_email varchar(50),
comgrp_member_date date not null,
comgrp_member_grade varchar(3) not null default 'C'
);

insert into comgrp_member_tbl values ('com11111', 'com11111', 'C', '기업1', '기업관리자1', '기업사업자번호1', '010-1000-0000', 'com1@Nate.com', now(), default);
insert into comgrp_member_tbl values ('grp11111', 'grp11111', 'G', '단체1', '단체관리자1', '단체사업자번호1', '010-2000-0000', 'grp1@Nate.com', now(), default);
insert into comgrp_member_tbl values ('com22222', 'com22222', 'C', '기업2', '기업관리자2', '기업사업자번호2', '010-1000-0001', 'com2@Nate.com', now(), default);
insert into comgrp_member_tbl values ('grp22222', 'grp22222', 'G', '단체2', '단체관리자2', '단체사업자번호2', '010-2000-0001', 'grp2@Nate.com', now(), default);

select * from comgrp_member_tbl;

create table admin_tbl(
admin_id varchar(30) not null primary key,
admin_pw varchar(30) not null,
admin_name varchar(30) not null,
admin_phone varchar(15) not null,
admin_date date not null,
admin_grade varchar(3) not null default 'C'
);

insert into admin_tbl values ('nsh00000', 'nsh00000', '노승현', '010-8883-1564', now(), 'S');
insert into admin_tbl values ('jjh00000', 'jjh00000', '주종환', '010-0000-0000', now(), 'A');
insert into admin_tbl values ('kmj00000', 'kmj00000', '김무준', '010-1111-1111', now(), 'B');

select * from admin_tbl;

create table donation_tbl(
donation_no int auto_increment not null primary key,
donation_member_id varchar(30) not null,
donation_money int not null,
donation_date date not null,
donation_campaign varchar(30) not null,
donation_type varchar(10) not null,
pay_type varchar(10) not null,
pay_status varchar(1) not null,

constraint member_donation_fk foreign key(donation_member_id)
references normal_member_tbl(normal_member_id)
);

create table campaign_tbl(
campaign_no int auto_increment not null primary key,
campaign_name varchar(30) not null,
campaign_member_id varchar(30) not null,
campaign_content nvarchar(2000) not null,
campaign_file nvarchar(50) not null,

constraint campaign_normal_member_fk foreign key(campaign_member_id)
references normal_member_tbl(normal_member_id),
constraint campaign_comgrp_member_fk foreign key(campaign_member_id)
references comgrp_member_tbl(comgrp_member_id)
);

create table campaign_list_tbl(
campaign_list_no int not null,
campaign_list_name varchar(30) not null,
campaign_list_group varchar(30) not null,
campaign_list_group_intro nvarchar(2000) not null,
campaign_list_all_fund_raised int not null,

constraint campaign_list_fk foreign key(campaign_list_no)
references campaign_tbl(campaign_no)
);

create table campaign_history_tbl(
campaign_support_no int not null,
campaign_support_campaign_name varchar(30) not null,
campaign_support_fund_raised int not null,
campaign_support_group_name varchar(30) not null,
campaign_support_date date not null,

constraint campaign_history_fk foreign key(campaign_support_no)
references campaign_tbl(campaign_no)
);
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
create table normal_member_tbl(
normal_member_id varchar(30) not null primary key,
normal_member_pw varchar(30) not null,
normal_member_name varchar(30) not null,
normal_member_birth date not null,
normal_member_phone varchar(15) not null,
normal_member_gender varchar(1) not null,
normal_member_email varchar(30),
normal_member_date date not null,
normal_member_grade varchar(2) not null
);

create table comgrp_member_tbl(
comgrp_member_id varchar(30) not null primary key,
comgrp_member_pw varchar(30) not null,
comgrp_member_category varchar(1) not null,
comgrp_member_name varchar(30) not null,
comgrp_manager_name varchar(30) not null,
comgrp_member_companyno varchar(30) not null,
comgrp_manager_phone varchar(15) not null,
comgrp_member_email varchar(30),
comgrp_member_date date not null,
comgrp_member_grade varchar(2) not null
);

create table admin_tbl(
admin_id varchar(30) not null primary key,
admin_pw varchar(30) not null,
admin_name varchar(30) not null,
admin_phone varchar(15) not null,
admin_date date not null,
admin_grade varchar(2) not null
);

create table donation_tbl(
donation_no int auto_increment not null primary key,
donation_member_id varchar(30) not null,
donation_money int not null,
donation_date date not null,
donation_campaign varchar(30) not null,
donation_type varchar(10) not null,
pay_type varchar(10) not null,
pay_status varchar(1) not null
);

create table campaign_tbl(
campaign_no int auto_increment not null primary key,
campaign_name varchar(30) not null,
campaign_member_id varchar(30) not null,
campaign_content varchar(2000) not null,
campaign_file varchar(50) not null
);

create table campaign_list_tbl(
campaign_list_no int not null primary key,
campaign_list_name varchar(30) not null,
campaign_list_group varchar(30) not null,
campaign_list_group_intro varchar(2000) not null,
campaign_list_all_fund_raised int not null
);

create table campaign_history_tbl(
campaign_support_no int not null primary key,
campaign_support_campaign_name varchar(30) not null,
campaign_support_fund_raised int not null,
campaign_support_group_name varchar(30) not null,
campaign_support_date date not null
);